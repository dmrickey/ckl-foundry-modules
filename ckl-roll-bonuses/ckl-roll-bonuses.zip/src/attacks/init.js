
// hooks
// pf1ActorRollAttack
// pf1ActorRollBab
// pf1ActorRollCmb
// pf1PreActorRollAttack
// pf1PreActorRollBab
// pf1PreActorRollCmb

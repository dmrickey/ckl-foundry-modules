export const signed = (/** @type {number} */ num) => `+${num}`.replace("+-", "-");

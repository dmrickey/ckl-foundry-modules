import './permanent-skill-bonuses.mjs';

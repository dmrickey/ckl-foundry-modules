
## v1.3.0
- Added Mythic Spell Focus
- Added Elemental Spell Focus, Greater, and Mythic
- Added a dictionary flag value that you can put on a buff (or feat or any item) to globally increase or decrease the DC for all spells for that actor

## v1.2.0
- Added Spell Focus and Greater Spell Focus configuration that automatically adds dc to spells for the chosen schools

## v1.0.0
- Initial release. Added skill configurations with support for Inspiration, dice bonus, and base die modification

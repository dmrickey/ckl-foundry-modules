export const truthiness = x => !!x;

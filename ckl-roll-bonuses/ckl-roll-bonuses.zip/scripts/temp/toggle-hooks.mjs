
// todo all of this pseudo code

Hooks.on('preUpdateItem', (item, changes, documentModificationContext, userId) {
    if (item.hasDictionaryFlag('maxUses'))
});

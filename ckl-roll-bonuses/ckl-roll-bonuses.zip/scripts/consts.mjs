export const CONFIG_BUTTON = '<i class="ra ra-cog ra-fw"></i>';
export const MODULE_NAME = 'ckl-roll-bonuses';

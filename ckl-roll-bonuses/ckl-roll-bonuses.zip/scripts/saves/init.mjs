
Hooks.on('actorRoll', (actor, type, saveId, options) => {
    if (type !== 'save') {
        return;
    }

    // todo do stuff
});

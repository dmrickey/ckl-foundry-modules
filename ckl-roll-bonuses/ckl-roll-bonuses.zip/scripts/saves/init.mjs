
// before dialog pops up
Hooks.on('pf1PreActorRollSave', (actor, options, save) => {
    // todo do stuff
});

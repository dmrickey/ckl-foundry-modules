import './spell-focus.mjs';
import './dc-bonus.mjs';
import './elemental-focus.mjs';

// before dialog pops up
Hooks.on('pf1PreActorRollConcentration', (actor, options, spellbook) => {
    // todo do stuff
});

// before dialog pops up
Hooks.on('pf1PreActorRollCl', (actor, options, spellbook) => {
    // todo do stuff
});

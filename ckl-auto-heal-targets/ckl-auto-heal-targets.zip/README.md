# Auto Heal Targets

When a healing ability is used, healing will automatically be applied to the targets. There are a couple settings of note, the most important is that you can make healing automatically apply onto to targets that have the same disposition as the actor that used the ability -- this is off by default.

## Manifest

https://github.com/dmrickey/ckl-foundry-modules/raw/main/ckl-auto-heal-targets/module.json

## License

MIT
